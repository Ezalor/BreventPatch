# 黑域 services.jar 补丁
替换打过黑域补丁的 services.jar。

当前版本：氢 OS v2.5.5
